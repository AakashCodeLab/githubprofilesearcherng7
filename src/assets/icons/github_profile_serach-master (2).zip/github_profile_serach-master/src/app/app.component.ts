import { Component } from '@angular/core';
import {GithubService} from './services/github.service';
@Component({
  selector: 'app-root',
  template: `
  <nav class="navbar navbar-default">
  <div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle collapse">
      <span class="sr-only">Toggle navi</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
     <a class="navbar-brand" href="#">GithubProfileSearch</a>
   </div>
   <div id="navbar" class="collapse navbar=collapse">
   <ul class="nav navbar-nav">
   
   </ul>
   
   
   </div> 

  </div>
</nav>
 <div class="container">
  <profile></profile>
  </div>
`,
  providers: [GithubService]
})
export class AppComponent  {  }
